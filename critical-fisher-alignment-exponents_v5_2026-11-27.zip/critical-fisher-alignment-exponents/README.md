# Optimal Sensor Directions for Locating a Stability Boundary: Convergence Rates and Cramér–Rao Cost under Nuisance-Parameter Elimination

Verification code for the manuscript by A. M. Tishin. Every numerical statement in the paper
and in its Supplementary Methods and Numerical Verification document is produced by one of
the scripts below; the console output of each is stored verbatim in `outputs/`.

These are **verification calculations**, not empirical data. All test systems are
finite-dimensional normal generators for which the reduced resolvent is known in closed
form, so every quantity has an exact reference value.

---

## Requirements

```
python >= 3.10
numpy
scipy
matplotlib   # only for rd_make_figure.py
```

Tested with numpy 2.5.3, scipy 1.18.1 and matplotlib 3.11.2. Each script is standalone,
takes no arguments and is run from the repository root as `python3 code/<name>.py`.
`temporal_resolution_test.py` and `leading_vector_robustness.py` take on the order of tens
of minutes; all other scripts finish within a few minutes.

---

## Quadrature

Unless a test is about sampling, the time integrals that define the Fisher operator are
evaluated by composite Gauss–Legendre quadrature (`code/quadrature.py`: 16 nodes on panels
of unit length), so the quadrature error is at round-off level. The misalignment angle is
computed as the norm of the stable components of the principal eigenvector, which avoids the
cancellation in `sqrt(1 − cos²θ)`. The reaction–diffusion scripts use the closed-form Fisher
operator, and compute the angle the same way. The sampling tests (`temporal_resolution_test.py`, `leading_vector_robustness.py`,
`common_pipeline_noise_comparison.py`) integrate sampled sensitivities on purpose, because
the effect of the sampling step is what they measure.

---

## Test systems

| Used by | Generator | Notes |
|---|---|---|
| Alignment tests | `L_c = diag(0, −1, −2.5)`, `a = 1` | reduced resolvent exact |
| Krylov tests | `L_c = diag(0, −1, −2.3, −4.1)`, `a = 1` | 2-dim cyclic compression reference `{−2.3187, −1.0001}` |
| Large-dimension example | `L(u) = D Δ_h + diag(r) + u diag(h)`, `n = 200, 800` | `D = 0.01`, `r = 1 + 0.6 cos 3πx − 0.8x`, `h = 0.5 + x`, Dirichlet |

---

## Scripts

**`verify_theorem_nu0.py`** — the two forward alignment laws, `(3/2|a|T)‖S_c q_c‖` without
nuisance projection and `6‖S_c²q_c‖/(|a|T²)` after the baseline projection. Both
ratios converge to unity; in the projected case `T(1 − ratio) = 2.0` at every `T`. Also prints
the quadrature check: halving the panel width changes the result by less than 10⁻¹⁴.

**`verify_theorem_nu1.py`** — the exceptional class is non-empty. `M = span{1, g}` with `g =`
`√(3/8) P̃₁ − √(5/8) P̃₂` gives `f(0) = 0` (numerically 2×10⁻¹⁴), `f′(0) = −5/4`,
`∫f² = 5/96`, `C₁ = 24/|a|` (24 with `a = 1`); the `T⁻³` law holds for `80 ≤ T ≤ 2560`.
Also checks codimension one at this exact point: tangent derivative of `J₁` equals `√15/6`.

**`verify_theorem_nu2.py`** — exact codimension-two point: `g = √(13/20) P̃₁ − (7/√156) P̃₂ − √(7/195) P̃₃`
gives `f = (7/3)x³ − (7/4)x²`, `f(0) = f′(0) = 0`, `f″(0) = −7/2`, `∫f² = 7/240`, `C₂ = 120/|a|`;
`D J₂` has rank 2 on the tangent plane (bordered determinant `−√91/4`); the `T⁻⁴` law holds for
`80 ≤ T ≤ 2560`.

**`genericity_codimension.py`** — rank test of the jet maps: `rank D J₁ = 1`
(singular value 0.761) and `rank D J₂ = 2` (singular values 4.530 and 0.0117).

**`rd_model.py`** — reaction–diffusion model, critical point, closed-form Fisher operator
with and without an unknown baseline (library used by the `rd_*` scripts).

**`rd_make_figure.py`** — Fig. 1 (`figures/fig_rd.pdf`, `.png`) and `data/rd_results.csv`:
alignment angle, Cramér–Rao excess of the critical-mode sensor, point-sensor variance ratio.

**`rd_crosscheck_fd.py`** — independent check (`n = 60`, `T = 100`): numerical derivative of
the matrix exponential and quadrature, compared through `sin θ_T`.

**`rd_fisher_frechet_check.py`** — Fisher operator from the Fréchet derivative of the matrix
exponential against the closed form; Krylov coefficient of the `T⁻³` correction.

**`rd_verify_numbers.py`** — recomputes the numbers quoted in Section 7.4 and Proposition 1,
including the differences between `n = 200` and `n = 800`.

**`rd_plugin_rotation.py`** — rotation of `v_c` under a pilot error `δu` in `u_c` (Rule 1):
`sin/δu → ‖S_c q_c‖`.

**`krylov_reconstruction.py`** — finite-order expansion of the normalized mixed block,
`r_T = b_T / K_cc(T)` compared directly with the one-term and three-term predictions of
Theorem 3, for a polynomial and a non-polynomial nuisance shape.

**`extraction_optimisation_and_noise.py`** — coefficient extraction: fit order, node
placement in `1/T`, ridge penalty, and a 400-realization perturbation sweep for four and
five fitted powers, with the admissibility filter of Section 8.4 (real pair in `[−60, 0)`).

**`temporal_resolution_test.py`** — quadrature bias of sampled sensitivities under three
integration rules. *The Simpson column is a negative control only*: that branch is
index-shifted for even sample counts. Read the rectangle and trapezoid columns.

**`leading_vector_robustness.py`** — end-to-end pipeline for the leading directed vector
`y₀ = S_c²q_c`: sampled sensitivities with additive noise, nuisance projection, trapezoidal
Fisher block, two-order fit; 60 realizations per noise level (Table S1).

**`common_pipeline_noise_comparison.py`** — injects noise once, at `sigma_s`, and extracts
both the leading vector (two-power fit) and the two-dimensional Krylov compression
(four-power fit) from the same realization, 400 realizations per level. Usability criteria
are named constants printed in the header of every run.

**`spectrum_recovery_illposedness.py`** — retained negative control: a three-power fit
without the additional order, showing the truncation failure that the order rule prevents.

---

## Reproducing the manuscript

| Manuscript location | Supplement | Script |
|---|---|---|
| Sec. 7.1–7.2, Table 1 | S3, S4 | `verify_theorem_nu0.py`, `verify_theorem_nu1.py`, `verify_theorem_nu2.py` |
| Sec. 7.3 | S5 | `genericity_codimension.py`, `verify_theorem_nu2.py` |
| Sec. 4.4, Sec. 7.4, Fig. 1, Rule 1 | S6 | `rd_*.py` |
| Sec. 8.2 | S7 | `krylov_reconstruction.py` |
| Sec. 8.4–8.5 | S8, S9, S13 | `extraction_optimisation_and_noise.py`, `spectrum_recovery_illposedness.py` |
| Sec. 8.4 | S9, S14 | `temporal_resolution_test.py` |
| Sec. 8.4–8.5, Rules 4–5 | S8, S12 | `extraction_optimisation_and_noise.py`, `common_pipeline_noise_comparison.py` |
| Sec. 11, Rule 6 | S10, Table S1 | `leading_vector_robustness.py`, `extraction_optimisation_and_noise.py` |
| Sec. 12 (iv), Rule 3 | S9, S12.6 | `temporal_resolution_test.py` |

All medians quoted in the manuscript and the Supplement come from scripts with fixed seeds
(`extraction_optimisation_and_noise.py`: 11, `common_pipeline_noise_comparison.py`: 101,
`leading_vector_robustness.py`: 17) and are reproduced exactly. Only the retained negative
control `spectrum_recovery_illposedness.py` draws without a seed; its noise rows vary between
runs and are not quoted anywhere.

---

## Licence

MIT.
