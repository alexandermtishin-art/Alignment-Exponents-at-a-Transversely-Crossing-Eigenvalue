import numpy as np
from quadrature import nodes, fisher, sin_angle
np.set_printoptions(precision=6, suppress=True)

# ---- normal critical generator: L_c = diag(0, -1, -2.5) in an orthonormal basis
n=3
lam=np.array([0.0,-1.0,-2.5])
Lc=np.diag(lam)
vc=np.array([1.0,0,0]); Pc=np.outer(vc,vc); Qc=np.eye(n)-Pc
Ls=np.diag(lam[1:])                      # on Ran Q_c
Sc_full=np.zeros((n,n)); Sc_full[1:,1:]=np.linalg.inv(Ls)   # S_c = L_s^{-1} Q_c

# ---- perturbation B_c = L'(u_c):  a = v_c^† B_c v_c ,  q_c = Q_c B_c v_c
rng=np.random.default_rng(7)
Bc=rng.normal(size=(n,n))*0.5
Bc[0,0]=1.0                              # set a = 1 explicitly
a=vc@Bc@vc
qc=Qc@Bc@vc
A=1.0                                    # preparation amplitude

def s_u(t):
    """exact sensitivity, Sec.3:  P_c part = A a t v_c ; Q_c part = A S_c (e^{L_s t}-I) q_c"""
    out=A*a*t*vc.copy()
    e=np.zeros(n); e[1:]=np.exp(lam[1:]*t)*qc[1:]
    out=out+A*(Sc_full@(e-qc))
    return out

def sin_theta(T,project=True):
    t,wt=nodes(T)
    S=np.array([s_u(ti) for ti in t])            # N x n
    nuis=np.ones((len(t),1)) if project else None  # unknown baseline: span{1}
    return sin_angle(fisher(S,wt,nuis))

Sc2qc=np.linalg.norm(Sc_full@Sc_full@qc)
Sc1qc=np.linalg.norm(Sc_full@qc)
print(f"a = {a:.6f}   ||S_c q_c|| = {Sc1qc:.6f}   ||S_c^2 q_c|| = {Sc2qc:.6f}")
print()
print("PROJECTED class (unknown DC offset, nu=0):  predicted  sin= 6||S_c^2 q_c||/(|a| T^2)")
print(f"{'T':>7} {'sin(theta) numeric':>20} {'predicted':>14} {'ratio':>9}")
for T in [40,80,160,320,640,1280,2560]:
    s=sin_theta(T,project=True); p=6*Sc2qc/abs(a)/T**2
    print(f"{T:>7} {s:20.6e} {p:14.6e} {s/p:9.4f}")
print()
print("UNPROJECTED class (stationary mixing retained):  predicted  sin=(3/(2|a|T))||S_c q_c||")
print(f"{'T':>7} {'sin(theta) numeric':>20} {'predicted':>14} {'ratio':>9}")
for T in [40,80,160,320,640,1280,2560]:
    s=sin_theta(T,project=False); p=1.5*Sc1qc/abs(a)/T
    print(f"{T:>7} {s:20.6e} {p:14.6e} {s/p:9.4f}")

# quadrature accuracy: halve and quarter the panel width and compare the projected angle
print()
print("quadrature check (projected): relative change of sin(theta) when the panel width is halved / quartered")
for T in (80,640,2560):
    r=[]
    for w in (1.0,0.5,0.25):
        t,wt=nodes(T,width=w); S=np.array([s_u(ti) for ti in t])
        r.append(sin_angle(fisher(S,wt,np.ones((len(t),1)))))
    print(f"  T={T:5d}   {abs(r[1]/r[0]-1):.1e}   {abs(r[2]/r[0]-1):.1e}")
