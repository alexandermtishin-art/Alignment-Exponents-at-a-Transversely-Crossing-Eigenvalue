import numpy as np
from quadrature import nodes, fisher, sin_angle
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(600); xq=(xq+1)/2; wq=wq/2
ip=lambda u,v: np.sum(wq*u(xq)*v(xq))
P1=lambda t: np.sqrt(3)*(2*np.asarray(t,float)-1)
P2=lambda t: np.sqrt(5)*(6*np.asarray(t,float)**2-6*np.asarray(t,float)+1)
u=lambda t: np.asarray(t,float)-0.5
th=np.arctan(-np.sqrt(5/3)); c1,c2=np.cos(th),np.sin(th)
g=lambda t: c1*P1(t)+c2*P2(t)

# ---------- full end-to-end test of the nu=1 prediction  sin ~ C_1 ||S_c^3 q_c|| / T^3
n=3; lam=np.array([0.0,-1.0,-2.5]); vc=np.array([1.,0,0])
Pc=np.outer(vc,vc); Qc=np.eye(n)-Pc
Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng=np.random.default_rng(7); Bc=rng.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc; A=1.0

def s_u(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return A*a*np.outer(t,vc) + A*(e-qc)@Sc.T

def sin_theta(T,M_basis):
    t,wt=nodes(T)
    S=s_u(t)
    B=np.stack([b(t/T) for b in M_basis],axis=1)          # nuisance basis, N x m
    return sin_angle(fisher(S,wt,B))

one=lambda t: np.ones_like(np.asarray(t,float))
f=lambda t: u(t)-ip(u,g)*g(t)
gp0=c1*2*np.sqrt(3)-c2*6*np.sqrt(5)              # g'(0), exact
fp0=1.0-ip(u,g)*gp0; F=ip(f,f)                     # f'(0), exact
print(f"f(0) = {f(0.0):.2e}   f'(0) = {fp0:.6f}   int f^2 = {F:.7f}")
C1=abs(fp0)/(abs(a)*F)
S3=np.linalg.norm(np.linalg.matrix_power(Sc,3)@qc)
print(f"C_1 = |f'(0)|/(|a| int f^2) = {C1:.6f}    ||S_c^3 q_c|| = {S3:.6f}")
print()
print(f"{'T':>7} {'sin(theta)':>16} {'predicted C1*||S^3q||/T^3':>26} {'ratio':>8}")
for T in [80,160,320,640,1280,2560]:
    s=sin_theta(T,[one,g]); p=C1*S3/T**3
    print(f"{T:>7} {s:16.6e} {p:26.6e} {s/p:8.4f}")

# exact codimension-one check: extend g to the sphere of span{P1,P2,P3} (zero P3 component) and
# differentiate J_1 = f(0) along the tangent direction (sqrt(5/8), sqrt(3/8), 0)
P3=lambda t: np.sqrt(7)*(20*np.asarray(t,float)**3-30*np.asarray(t,float)**2+12*np.asarray(t,float)-1)
Pb=[P1,P2,P3]
def J1(cf):
    gg=lambda t: sum(ci*p(t) for ci,p in zip(cf,Pb))
    return u(0.0)-ip(u,gg)*gg(0.0)
c0=np.array([np.sqrt(3/8),-np.sqrt(5/8),0.0]); d=np.array([np.sqrt(5/8),np.sqrt(3/8),0.0]); h=1e-6
dJ=(J1(np.cos(h)*c0+np.sin(h)*d)-J1(np.cos(-h)*c0+np.sin(-h)*d))/(2*h)
print()
print(f"codimension one: J_1 at the exact point = {J1(c0):+.1e};  tangent derivative = {dJ:.8f}  (sqrt(15)/6 = {np.sqrt(15)/6:.8f})")
