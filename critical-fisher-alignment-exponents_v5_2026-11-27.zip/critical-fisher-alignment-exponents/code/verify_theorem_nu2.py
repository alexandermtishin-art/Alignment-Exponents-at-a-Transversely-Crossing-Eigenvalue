"""Exact nu = 2 point (codimension two) and the T^-4 law.

g = sqrt(13/20) P1 - 7/sqrt(156) P2 - sqrt(7/195) P3   (orthonormal shifted Legendre)
gives f = (7/3) x^3 - (7/4) x^2, so f(0) = f'(0) = 0, f''(0) = -7/2, int f^2 = 7/240,
C_2 = |f''(0)|/(|a| int f^2) = 120.  Part 1 checks the jet and the rank of D J_2 on the
tangent plane of the unit sphere; part 2 checks sin(theta_T) = C_2 ||S_c^4 q_c|| T^-4."""
import numpy as np
from quadrature import nodes, fisher, sin_angle
from numpy.polynomial import legendre as Lg
from numpy.polynomial.legendre import leggauss

def Pt(j):                      # orthonormal shifted Legendre P~_j(x) = sqrt(2j+1) P_j(2x-1), as a poly in x
    c=np.zeros(j+1); c[j]=1.0
    p=Lg.leg2poly(c)            # coefficients in y = 2x-1
    q=np.polynomial.Polynomial(p)(np.polynomial.Polynomial([-1,2]))
    return np.sqrt(2*j+1)*q
Pb=[Pt(1),Pt(2),Pt(3)]
coef=np.array([np.sqrt(13/20), -7/np.sqrt(156), -np.sqrt(7/195)])
g=sum(ci*p for ci,p in zip(coef,Pb))
xq,wq=leggauss(200); xq=(xq+1)/2; wq=wq/2
ip=lambda p,q: np.sum(wq*p(xq)*q(xq))
u=np.polynomial.Polynomial([-0.5,1.0]); one=np.polynomial.Polynomial([1.0])
beta=ip(u,g); f=u-beta*g; F=ip(f,f)
d=[f.deriv(k)(0.0) if k else f(0.0) for k in range(3)]
print("=== 1. exact nu = 2 point ===")
print(f"  |g| = {np.sqrt(ip(g,g)):.12f}   <g,1> = {ip(g,one):+.1e}")
print(f"  f(0) = {d[0]:+.1e}   f'(0) = {d[1]:+.1e}   f''(0) = {d[2]:+.12f}   int f^2 = {F:.12f}  (7/240 = {7/240:.12f})")
rows=np.array([[-ip(u,dg)*(g.deriv(k)(0.0) if k else g(0.0)) - beta*(dg.deriv(k)(0.0) if k else dg(0.0)) for dg in Pb] for k in range(2)])
nrm=np.array([ip(g,dg) for dg in Pb])
M=np.vstack([rows,nrm]); nv=nrm/np.linalg.norm(nrm)
print(f"  det[D J_2 ; normal] = {np.linalg.det(M):+.12f}   (-sqrt(91)/4 = {-np.sqrt(91)/4:+.12f})")
print(f"  singular values of D J_2 on the tangent plane: {np.linalg.svd(rows@(np.eye(3)-np.outer(nv,nv)),compute_uv=False)}")
print("  -> rank 2 at a point with J_2 = 0: {nu >= 2} is locally an isolated point (codimension 2)")
print()
n=3; lam=np.array([0.0,-1.0,-2.5]); vc=np.array([1.,0,0])
Qc=np.eye(n)-np.outer(vc,vc); Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng=np.random.default_rng(7); Bc=rng.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc
def s_u(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return a*np.outer(t,vc) + (e-qc)@Sc.T
C2=abs(d[2])/(abs(a)*F); S4=np.linalg.norm(np.linalg.matrix_power(Sc,4)@qc)
print("=== 2. T^-4 law ===")
print(f"  C_2 = {C2:.6f}   ||S_c^4 q_c|| = {S4:.6f}")
print(f"{'T':>7} {'sin(theta)':>16} {'C2*||S^4q||/T^4':>18} {'ratio':>8} {'T(1-ratio)':>11}")
for T in [80,160,320,640,1280,2560]:
    t,wt=nodes(T); B=np.stack([one(t/T),g(t/T)],axis=1)
    s=sin_angle(fisher(s_u(t),wt,B)); p=C2*S4/T**4
    print(f"{T:>7} {s:16.6e} {p:18.6e} {s/p:8.4f} {T*(1-s/p):11.4f}")
