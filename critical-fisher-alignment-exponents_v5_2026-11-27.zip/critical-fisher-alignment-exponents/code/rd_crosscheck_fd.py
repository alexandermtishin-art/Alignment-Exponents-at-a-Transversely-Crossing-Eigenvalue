import os
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
import numpy as np, rd_model as R
from scipy.sparse.linalg import expm_multiply
n=60; M=R.build(n); T=100.0; N=200001
x=M['x']; hx=1/(n+1)
lap=(np.diag(-2*np.ones(n))+np.diag(np.ones(n-1),1)+np.diag(np.ones(n-1),-1))/hx**2
r=1.0+0.6*np.cos(3*np.pi*x)-0.8*x; h=0.5+x
L=lambda u: 0.01*lap+np.diag(r)+u*np.diag(h)
x0=M['vc']; du=1e-5
X=lambda u: expm_multiply(L(u), x0, start=0, stop=T, num=N, endpoint=True)
S=(X(M['uc']+du)-X(M['uc']-du))/(2*du)          # independent finite-difference sensitivity, shape (N,n)
t=np.linspace(0,T,N); wq=np.full(N,t[1]); wq[0]=wq[-1]=t[1]/2
for proj in (False,True):
    SS = S - (wq@S)/T if proj else S
    K=(SS*wq[:,None]).T@SS
    ev,V=np.linalg.eigh(K); w=V[:,-1]
    sin_fd=np.sqrt(max(0,1-(w@M['vc'])**2))
    ra=R.analyse(M,T,proj)
    print(f"proj={proj}: sin finite-diff/quadrature={sin_fd:.6e}  analytic={ra['sin']:.6e}  rel.diff={abs(sin_fd/ra['sin']-1):.2e}")
