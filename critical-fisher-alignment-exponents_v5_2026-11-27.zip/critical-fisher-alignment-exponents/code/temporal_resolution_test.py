"""
Temporal-resolution test (Sec. 8.4, Supplement S8).

Separates quadrature bias from statistical error by running the noise-free
pipeline at a sequence of sampling steps under three integration rules.

Note: the Simpson branch is index-shifted for even sample counts and its
column is NOT a physical result; it is retained only to show that a naive
higher-order rule applied to a mismatched grid is worse than trapezoid.
Read the rectangle and trapezoid columns.
"""
import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(600); xq=(xq+1)/2; wq=wq/2
ip=lambda a,b: np.sum(wq*a(xq)*b(xq))
n=4; lam=np.array([0.0,-1.0,-2.3,-4.1]); vc=np.zeros(n); vc[0]=1
Qc=np.eye(n)-np.outer(vc,vc); Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng0=np.random.default_rng(3); Bc=rng0.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc
def s_exact(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return a*np.outer(t,vc)+(e-qc)@Sc.T
one=lambda t: np.ones_like(np.asarray(t,float)); gexp=lambda t: np.exp(-3*np.asarray(t,float))
basis=[one,gexp]
G=np.array([[ip(g,h) for h in basis] for g in basis]); bb=np.array([ip(lambda s:s,g) for g in basis])
cc=np.linalg.solve(G,bb); f=lambda s: np.asarray(s,float)-sum(ci*g(s) for ci,g in zip(cc,basis))
F=ip(f,f); h=1e-3
der=[f(0.0),(-3*f(0.0)+4*f(h)-f(2*h))/(2*h),(2*f(0.0)-5*f(h)+4*f(2*h)-f(3*h))/h**2,
     (-5*f(0.0)+18*f(h)-24*f(2*h)+14*f(3*h)-3*f(4*h))/(2*h**3)]
Ytrue=np.array([np.linalg.matrix_power(Sc,j+2)@qc for j in range(3)]).T[1:,:]

def weights(M,dt,rule):
    w=np.full(M,dt)
    if rule=='rect': return w
    if rule=='trap': w[0]=w[-1]=dt/2; return w
    if rule=='simp':
        if M%2==0: M-=1
        w=np.zeros(M); w[0]=w[-1]=dt/3; w[1:-1:2]=4*dt/3; w[2:-1:2]=2*dt/3; return w

def r_meas(T,dt_s,rule):
    M=int(T/dt_s)+1; t=np.linspace(0,T,M); dt=t[1]-t[0]
    S=s_exact(t)
    B=np.stack([b(t/T) for b in basis],axis=1); Qb,_=np.linalg.qr(B); S=S-Qb@(Qb.T@S)
    w=weights(M,dt,rule); m=len(w); K=(S[:m]*w[:,None]).T@S[:m]
    return (Qc@K@vc)/(vc@K@vc)
def extract(Ts,R,Nt=4,ridge=1e-8):
    D=np.array([[T**-(j+2) for j in range(Nt)] for T in Ts]); sc=np.linalg.norm(D,axis=0); Ds=D/sc
    C=np.linalg.solve(Ds.T@Ds+ridge*np.eye(Nt),Ds.T@R); C=(C.T/sc).T
    return np.array([C[j]*(a*F)/((-1)**(j+1)*der[j]) for j in range(3)]).T
def spec(Y,k=2):
    V,_=np.linalg.qr(Y[:,:k]); Ain=np.linalg.lstsq(V,Y[:,:k],rcond=None)[0]
    Aout=np.linalg.lstsq(V,Y[:,1:k+1],rcond=None)[0]
    return np.sort(np.real(1/np.linalg.eigvals(Aout@np.linalg.inv(Ain))))
zmin,zmax=1/3000,1/30; k=np.arange(14)
Tche=np.sort(1/((zmax+zmin)/2+(zmax-zmin)/2*np.cos((2*k+1)*np.pi/28)))
print(f"target (exact Krylov) = {np.round(spec(Ytrue),4)}   [noise-free; quadrature error only]\n")
print(f"{'dt':>8} {'dt*Delta':>10} {'rectangle':>22} {'trapezoid':>22} {'Simpson':>22}")
for dts in (0.2,0.1,0.05,0.02,0.01,0.005):
    row=[]
    for rule in ('rect','trap','simp'):
        R=np.array([r_meas(T,dts,rule) for T in Tche])[:,1:]
        try: row.append(np.round(spec(extract(Tche,R)),3))
        except Exception: row.append(np.array([np.nan,np.nan]))
    print(f"{dts:8.3f} {dts*4.1:10.3f} {str(row[0]):>22} {str(row[1]):>22} {str(row[2]):>22}")
