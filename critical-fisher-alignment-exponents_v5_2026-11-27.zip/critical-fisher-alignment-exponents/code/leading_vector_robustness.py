"""
Leading-vector robustness test (Sec. 8.5, Supplement S9, S12).

End-to-end pipeline: sampled sensitivities with additive Gaussian noise,
nuisance projection, trapezoidal Fisher block, two-order coefficient fit,
and recovery of y0 = S_c^2 q_c. Reports median and interquartile spread of
the angular and norm errors over 60 realizations per noise level.
"""
import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(600); xq=(xq+1)/2; wq=wq/2
ip=lambda a,b: np.sum(wq*a(xq)*b(xq))
n=4; lam=np.array([0.0,-1.0,-2.3,-4.1]); vc=np.zeros(n); vc[0]=1
Qc=np.eye(n)-np.outer(vc,vc); Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng0=np.random.default_rng(3); Bc=rng0.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc
def s_exact(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return a*np.outer(t,vc)+(e-qc)@Sc.T
one=lambda t: np.ones_like(np.asarray(t,float)); gexp=lambda t: np.exp(-3*np.asarray(t,float))
basis=[one,gexp]
G=np.array([[ip(g,h) for h in basis] for g in basis]); bb=np.array([ip(lambda s:s,g) for g in basis])
cc=np.linalg.solve(G,bb); f=lambda s: np.asarray(s,float)-sum(ci*g(s) for ci,g in zip(cc,basis))
F=ip(f,f); h=1e-3
der=[f(0.0),(-3*f(0.0)+4*f(h)-f(2*h))/(2*h),(2*f(0.0)-5*f(h)+4*f(2*h)-f(3*h))/h**2,
     (-5*f(0.0)+18*f(h)-24*f(2*h)+14*f(3*h)-3*f(4*h))/(2*h**3)]
y0true=(Sc@Sc@qc)[1:]; Ytrue=np.array([np.linalg.matrix_power(Sc,j+2)@qc for j in range(3)]).T[1:,:]

DT=0.06   # dt*Delta_fast = 0.246... use finer for the eigenvalue arm
def r_meas(T,dts,sig,g):
    M=int(T/dts)+1; t=np.linspace(0,T,M); dt=t[1]-t[0]
    S=s_exact(t)+ (sig*g.normal(size=(M,n)) if sig>0 else 0)
    B=np.stack([b(t/T) for b in basis],axis=1); Qb,_=np.linalg.qr(B); S=S-Qb@(Qb.T@S)
    w=np.full(M,dt); w[0]=w[-1]=dt/2
    K=(S*w[:,None]).T@S
    return (Qc@K@vc)/(vc@K@vc)
def extract(Ts,R,Nt,ridge=1e-8):
    D=np.array([[T**-(j+2) for j in range(Nt)] for T in Ts]); sc=np.linalg.norm(D,axis=0); Ds=D/sc
    C=np.linalg.solve(Ds.T@Ds+ridge*np.eye(Nt),Ds.T@R); C=(C.T/sc).T
    return np.array([C[j]*(a*F)/((-1)**(j+1)*der[j]) for j in range(Nt)]).T

zmin,zmax=1/3000,1/30; k=np.arange(14)
Tche=np.sort(1/((zmax+zmin)/2+(zmax-zmin)/2*np.cos((2*k+1)*np.pi/28)))
print("Leading vector y0 = S_c^2 q_c :  robustness under the realistic pipeline")
print("trapezoid, dt = 0.02 (dt*Delta_fast = 0.082), 14 windows, N=2 fitted orders\n")
print(f"{'sigma_s':>9} {'angle to y0 (deg)':>19} {'IQR':>9} {'rel norm err':>14} {'IQR':>9}")
for sig in (0,1e-6,1e-5,1e-4,1e-3,1e-2,1e-1):
    ang=[];rel=[]
    g=np.random.default_rng(17)
    reps=1 if sig==0 else 60
    for _ in range(reps):
        R=np.array([r_meas(T,0.02,sig,g) for T in Tche])[:,1:]
        Y=extract(Tche,R,2)
        y=Y[:,0]
        ang.append(np.degrees(np.arccos(np.clip(abs(y@y0true)/(np.linalg.norm(y)*np.linalg.norm(y0true)),-1,1))))
        rel.append(abs(np.linalg.norm(y)/np.linalg.norm(y0true)-1))
    q=lambda v: 0.0 if len(v)<5 else np.percentile(v,75)-np.percentile(v,25)
    print(f"{sig:9.0e} {np.median(ang):19.4f} {q(ang):9.4f} {np.median(rel):14.5f} {q(rel):9.5f}")
