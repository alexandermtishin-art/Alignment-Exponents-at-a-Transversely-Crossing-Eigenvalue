"""Composite Gauss-Legendre quadrature on [0, T] and the projected Fisher operator.

Panels of unit width (shorter than every stable time scale of the test generators)
with 16 nodes each, so the quadrature error is at the level of double-precision
round-off. The misalignment angle is computed as the norm of the stable components
of the principal eigenvector, which avoids the sqrt(1 - cos^2) cancellation floor."""
import numpy as np
from numpy.polynomial.legendre import leggauss

def nodes(T, width=1.0, order=16):
    x, w = leggauss(order)
    m = max(1, int(np.ceil(T/width))); edges = np.linspace(0.0, T, m+1)
    h = np.diff(edges)
    t = (edges[:-1, None] + 0.5*h[:, None]*(x[None, :]+1)).ravel()
    wt = (0.5*h[:, None]*w[None, :]).ravel()
    return t, wt

def fisher(S, wt, nuisance=None):
    """S: N x n sensitivities at the nodes; nuisance: N x m basis or None.
    Returns K = int (Pi_perp s)(Pi_perp s)^T dt with the L2(0,T) projection."""
    if nuisance is not None:
        Bw = nuisance*np.sqrt(wt)[:, None]; Sw = S*np.sqrt(wt)[:, None]
        Q, _ = np.linalg.qr(Bw)
        Sw = Sw - Q@(Q.T@Sw)
        return Sw.T@Sw
    return (S*wt[:, None]).T@S

def sin_angle(K, critical_index=0):
    ev, V = np.linalg.eigh(K); w = V[:, np.argmax(ev)]
    return np.linalg.norm(np.delete(w, critical_index))
