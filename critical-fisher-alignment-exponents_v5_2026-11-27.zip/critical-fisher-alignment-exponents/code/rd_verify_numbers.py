import os
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
import numpy as np, rd_model as R, csv
from scipy.linalg import expm
rows=list(csv.DictReader(open(os.path.join(ROOT,'data','rd_results.csv')).read().splitlines()[0:1][0].lstrip('# ').split('\n')+open(os.path.join(ROOT,'data','rd_results.csv')).read().splitlines()[1:]))
Ts=[50,70,100,140,200,280,400,560,800,1130,1600]
res={}
for n in (200,800):
    M=R.build(n)
    mu=M['mu_s']; vc=M['vc']
    print(f"n={n} uc={M['uc']:.5f} a={M['a']:.5f} mu_c={M['mu_c']:.2e} Delta={-mu.max():.4f} fastest={-mu.min():.4e}  |vc|max^-2={np.abs(vc).max()**-2:.4f}")
    for p in (0,1):
        for T in Ts:
            r=R.analyse(M,T,bool(p)); res[(n,p,T)]=r
for (n,p,T),r in res.items():
    s2=r['sin']**2; ex=r['var_ratio_vc']-1
    print(n,p,T, f"ratio={r['ratio']:.6f} T(1-ratio)={T*(1-r['ratio']):.5f} ex={ex:.4e} ex/s2-1={ex/s2-1:+.2e} pt={r['var_ratio_pt']:.3f} y0err={r['y0_err']}  l2/l1={r['lam2_over_lam1']:.2e}")
print("max n200 vs n800 rel diff in sin:", max(abs(res[(200,p,T)]['sin']/res[(800,p,T)]['sin']-1) for p in (0,1) for T in Ts))
print("max n200 vs n800 rel diff in ratio:", max(abs(res[(200,p,T)]['ratio']/res[(800,p,T)]['ratio']-1) for p in (0,1) for T in Ts))
print("max n200 vs n800 rel diff in excess variance:", max(abs((res[(200,p,T)]['var_ratio_vc']-1)/(res[(800,p,T)]['var_ratio_vc']-1)-1) for p in (0,1) for T in Ts))
print("max |ex/s2-1|:", max(abs((r['var_ratio_vc']-1)/r['sin']**2-1) for r in res.values()))
# predicted squared leading (28)
for n in (200,800):
    M=R.build(n); mu=M['mu_s'];q=M['q'];a=M['a']
    for T in (400,1600):
        print(n,T,"9/4 pred",9*np.linalg.norm(q/mu)**2/(4*a*a*T*T),"36 pred",36*np.linalg.norm(q/mu**2)**2/(a*a*T**4))
