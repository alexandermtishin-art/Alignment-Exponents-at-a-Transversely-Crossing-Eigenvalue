"""Rotation of the critical eigenvector under a pilot error du in u_c (Rule 1):
sin(angle)/|du| -> ||S_c q_c|| as du -> 0."""
import numpy as np
from rd_model import build
for n in (200, 800):
    M = build(n); x = M['x']; hx = 1/(n+1)
    lap = (np.diag(-2*np.ones(n))+np.diag(np.ones(n-1),1)+np.diag(np.ones(n-1),-1))/hx**2
    L = lambda u: 0.01*lap + np.diag(1+0.6*np.cos(3*np.pi*x)-0.8*x) + u*np.diag(0.5+x)
    Sq = np.linalg.norm(M['q']/M['mu_s'])
    for du in (1e-2, 1e-3, 1e-4):
        v = np.linalg.eigh(L(M['uc']+du))[1][:, -1]
        s = np.sqrt(max(0.0, 1-(v@M['vc'])**2))
        print(f"n={n} du={du:.0e} sin/du={s/du:.6f} ||S_c q_c||={Sq:.6f}")
