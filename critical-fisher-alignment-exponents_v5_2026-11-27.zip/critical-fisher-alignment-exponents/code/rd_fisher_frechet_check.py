import os
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
import numpy as np, rd_model as R
from scipy.linalg import expm_frechet, expm
n=30; M=R.build(n); T=60.0
x=M['x']; hx=1/(n+1)
lap=(np.diag(-2*np.ones(n))+np.diag(np.ones(n-1),1)+np.diag(np.ones(n-1),-1))/hx**2
Lc=0.01*lap+np.diag(1.0+0.6*np.cos(3*np.pi*x)-0.8*x)+M['uc']*np.diag(0.5+x); B=np.diag(0.5+x)
# exact sensitivity via Frechet derivative, Gauss-Legendre on subintervals
g,wg=np.polynomial.legendre.leggauss(20); edges=np.linspace(0,T,601)
ts=[];ws=[]
for a0,b0 in zip(edges[:-1],edges[1:]):
    ts+=list((b0-a0)/2*g+(a0+b0)/2); ws+=list((b0-a0)/2*wg)
ts=np.array(ts);ws=np.array(ws)
S=np.array([expm_frechet(Lc*t,B*t,compute_expm=False)@M['vc'] for t in ts])
for proj in (False,True):
    SS=S-(ws@S)/T if proj else S
    K=(SS*ws[:,None]).T@SS
    Ka=R.fisher(M,T,proj); U=M['U']; Kp=U@np.roll(np.roll(Ka,-1,0),-1,1)@U.T
    print(proj,"rel Frobenius diff",np.linalg.norm(K-Kp)/np.linalg.norm(K), "mixed block rel diff", np.linalg.norm((K-Kp)@M['vc'])/np.linalg.norm(Kp@M['vc']))
# Theorem-3 next-order check
for nn in (200,):
    M=R.build(nn); mu=M['mu_s'];q=M['q']
    y0=q/mu**2;y1=q/mu**3
    print("2||S^3q||/||S^2q|| =",2*np.linalg.norm(y1)/np.linalg.norm(y0), " -2<y0,y1>/|y0|^2=",-2*y0@y1/(y0@y0))
