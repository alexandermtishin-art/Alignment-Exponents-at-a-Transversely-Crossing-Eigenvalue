"""
common_pipeline_noise_comparison.py

Places the leading directed vector and the two-dimensional Krylov spectral
compression on a SINGLE noise coordinate, so that the two robustness numbers
can be compared directly.

Both quantities are extracted from the same noisy realisation of the sampled
sensitivity. Noise is injected once, at sigma_s, on each component of the
estimated sensitivity at each sampling instant -- the most primitive stage of
the pipeline. Everything downstream (nuisance projection, trapezoidal Fisher
block, coefficient regression) is common to the two estimates.

This replaces an earlier pair of tests in which the leading vector was
perturbed at sigma_s while the spectral compression was perturbed at the level
of the already-processed block r_T. Those two tests did not share a noise
coordinate and therefore did not define a noise ratio.

Leading vector uses N_fit = 2 fitted inverse-time powers.
Spectral compression uses N_fit = 4, as required by N_fit >= d + 2 with d = 2.

Usability criteria and the admissibility filter are stated explicitly below and
applied identically at every noise level, so that the reported separation is a
reproducible numerical statement rather than a reading of the table by eye.
"""

import numpy as np
from numpy.polynomial.legendre import leggauss

# ---------------------------------------------------------------- test system
n = 4
lam = np.array([0.0, -1.0, -2.3, -4.1])
OMEGA_FAST = np.max(np.abs(lam))      # real spectrum here, so this is the fastest decay
vc = np.zeros(n); vc[0] = 1.0
Qc = np.eye(n) - np.outer(vc, vc)
Sc = np.zeros((n, n)); Sc[1:, 1:] = np.diag(1.0 / lam[1:])
rng0 = np.random.default_rng(3)
Bc = rng0.normal(size=(n, n)) * 0.5; Bc[0, 0] = 1.0
a = vc @ Bc @ vc
qc = Qc @ Bc @ vc

def s_exact(t):
    e = np.zeros((len(t), n))
    e[:, 1:] = np.exp(np.outer(t, lam[1:])) * qc[1:]
    return a * np.outer(t, vc) + (e - qc) @ Sc.T

# ------------------------------------------------------------ nuisance family
# M = span(1, exp(-3x)): a non-polynomial scale-covariant shape, chosen because
# its boundary derivatives are nonzero for j = 0,1,2,3, which is what a
# four-power fit requires.
xq, wq = leggauss(600); xq = (xq + 1) / 2; wq = wq / 2
ip = lambda u, v: np.sum(wq * u(xq) * v(xq))
one  = lambda t: np.ones_like(np.asarray(t, float))
gexp = lambda t: np.exp(-3 * np.asarray(t, float))
basis = [one, gexp]

G = np.array([[ip(g, hh) for hh in basis] for g in basis])
b = np.array([ip(lambda s: s, g) for g in basis])
c = np.linalg.solve(G, b)
f = lambda s: np.asarray(s, float) - sum(ci * g(s) for ci, g in zip(c, basis))
F = ip(f, f)
der = [f(0.0), 1.0 + 3*c[1], -9*c[1], 27*c[1]]   # exact: f = x - c0 - c1 exp(-3x)

# ------------------------------------------------------------- noisy pipeline
DT = 0.01                              # dt * Omega_fast = 0.041
_CACHE = {}

def _window(T):
    if T not in _CACHE:
        M = int(T / DT) + 1
        t = np.linspace(0, T, M); dt = t[1] - t[0]
        S0 = s_exact(t)
        B = np.stack([bb(t / T) for bb in basis], axis=1)
        Q, _ = np.linalg.qr(B)
        w = np.full(M, dt); w[0] = w[-1] = dt / 2
        _CACHE[T] = (S0, Q, w, M)
    return _CACHE[T]

def r_T(T, sigma_s, gen):
    S0, Q, w, M = _window(T)
    S = S0 if sigma_s == 0 else S0 + sigma_s * gen.normal(size=(M, n))
    S = S - Q @ (Q.T @ S)
    K = (S * w[:, None]).T @ S
    return (Qc @ K @ vc) / (vc @ K @ vc)

def coefficients(Ts, R, Nfit, ridge=1e-8):
    D = np.array([[T ** -(j + 2) for j in range(Nfit)] for T in Ts])
    sc = np.linalg.norm(D, axis=0); Ds = D / sc
    C = np.linalg.solve(Ds.T @ Ds + ridge * np.eye(Nfit), Ds.T @ R)
    C = (C.T / sc).T
    return np.array([C[j] * (a * F) / ((-1) ** (j + 1) * der[j]) for j in range(Nfit)]).T

def spectrum(Y, k=2):
    V, _ = np.linalg.qr(Y[:, :k])
    Ain = np.linalg.lstsq(V, Y[:, :k], rcond=None)[0]
    Aout = np.linalg.lstsq(V, Y[:, 1:k + 1], rcond=None)[0]
    return np.sort(1.0 / np.linalg.eigvals(Aout @ np.linalg.inv(Ain)))

# --------------------------------------------------------- admissibility filter
def admissible(s):
    """A reconstruction is admissible when the compression returns a real,
    strictly stable, finite pair inside a stated bracket. Rejecting a draw here
    is what the text calls a failure of the admissibility filter."""
    if s is None:                            return False
    if not np.all(np.isfinite(s)):           return False   # nonfinite fit or singular compression
    if np.max(np.abs(np.imag(s))) > 1e-8:    return False   # complex reciprocal Ritz pair
    r = np.real(s)
    if np.any(r >= 0):                       return False   # inferred rate not stable
    if np.any(r < -60):                      return False   # outside the bracket
    return True

# ------------------------------------------------------------ usability criteria
ANGLE_MAX   = 2.0     # deg; leading vector usable if the median angular error is below this
RITZ_RELERR = 0.10    # both reciprocal Ritz medians within 10% of the reference
RITZ_IQR    = 0.25    # relative interquartile width below this
FAIL_MAX    = 0.05    # admissibility-filter failure rate below 5%

# --------------------------------------------------------------------- windows
zmin, zmax = 1 / 600, 1 / 30
kk = np.arange(10)
Ts = np.sort(1 / ((zmax + zmin) / 2 + (zmax - zmin) / 2 * np.cos((2 * kk + 1) * np.pi / 20)))

y0_true = (Sc @ Sc @ qc)[1:]
Ytrue = np.array([np.linalg.matrix_power(Sc, j + 2) @ qc for j in range(3)]).T[1:, :]
REF = np.real(spectrum(Ytrue))

print(__doc__)
print("true stable spectrum      : {}".format(lam[1:]))
print("reciprocal Ritz reference : {}   (2-dim compression of S_c, exact vectors)".format(np.round(REF, 4)))
print("nuisance space            : M = span(1, exp(-3x));  f = (I - Pi_M) x")
print("  boundary derivatives    : " + "  ".join(
      "f^({})(0)={:+.6f}".format(j, der[j]) for j in range(4)))
print("                            four consecutive nonzero derivatives, as N_fit = 4 requires")
print("sampling                  : dt = {}, dt*Omega_fast = {:.3f}, {} windows, T in [30, 600]".format(
      DT, DT * OMEGA_FAST, len(Ts)))
print("criteria                  : leading vector usable if median angle < {} deg;".format(ANGLE_MAX))
print("                            compression usable if both reciprocal Ritz medians lie")
print("                            within {:.0%} of the reference, relative IQR < {:.2f},".format(
      RITZ_RELERR, RITZ_IQR))
print("                            and the failure rate is < {:.0%}".format(FAIL_MAX))
print()

REPS = 400
print("{:>9} | {:>9} {:>8} {:>4} | {:>9} {:>7} | {:>9} {:>7} | {:>6} {:>4}".format(
      "sigma_s", "y0 angle", "IQR", "ok", "lam_1", "relIQR", "lam_2", "relIQR", "fail%", "ok"))
print("-" * 94)

for sigma_s in (0.0, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2, 1e-1):
    gen = np.random.default_rng(101)
    ang, spec, fails = [], [], 0
    reps = 1 if sigma_s == 0 else REPS
    for _ in range(reps):
        R = np.array([r_T(T, sigma_s, gen) for T in Ts])[:, 1:]
        y = coefficients(Ts, R, 2)[:, 0]
        ang.append(np.degrees(np.arccos(np.clip(
            abs(y @ y0_true) / (np.linalg.norm(y) * np.linalg.norm(y0_true)), -1, 1))))
        try:
            s = spectrum(coefficients(Ts, R, 4)[:, :3])
        except Exception:
            s = None
        if admissible(s): spec.append(np.real(s))
        else:             fails += 1
    q = lambda v: 0.0 if len(v) < 3 else np.percentile(v, 75) - np.percentile(v, 25)
    med_ang = float(np.median(ang))
    ang_ok = "yes" if med_ang < ANGLE_MAX else "no"
    fr = fails / reps
    if spec:
        sp = np.array(spec)
        m = np.median(sp, axis=0)
        rel_iqr = (np.percentile(sp, 75, axis=0) - np.percentile(sp, 25, axis=0)) / np.abs(REF)
        rel_err = np.abs(m - REF) / np.abs(REF)
        ok = ("yes" if (np.all(rel_err <= RITZ_RELERR) and np.all(rel_iqr <= RITZ_IQR)
                        and fr <= FAIL_MAX) else "no")
        print("{:9.0e} | {:9.4f} {:8.4f} {:>4} | {:9.4f} {:7.3f} | {:9.4f} {:7.3f} | {:6.1f} {:>4}".format(
              sigma_s, med_ang, q(ang), ang_ok, m[0], rel_iqr[0], m[1], rel_iqr[1], 100 * fr, ok))
    else:
        print("{:9.0e} | {:9.4f} {:8.4f} {:>4} | {:>9} {:>7} | {:>9} {:>7} | {:6.1f} {:>4}".format(
              sigma_s, med_ang, q(ang), ang_ok, "--", "--", "--", "--", 100 * fr, "no"))

print()
print("Both columns are driven by the same sigma_s, injected once on the sampled")
print("sensitivity, and both are extracted from the same noisy realisation. The two")
print("'ok' columns apply the stated criteria, so the separation between the largest")
print("sigma_s at which each estimate remains usable is a reproducible number.")
