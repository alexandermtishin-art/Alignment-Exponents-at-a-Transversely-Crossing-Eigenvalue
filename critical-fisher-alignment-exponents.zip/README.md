# Alignment Exponents and Reduced-Resolvent Structure of the Critical Fisher Information Block

Verification code for the manuscript. Every numerical statement in the paper and in its
Supplementary Methods and Numerical Verification document is produced by one of the
scripts below; the console output of each is stored verbatim in `outputs/`.

These are **verification calculations**, not empirical data. All test systems are
finite-dimensional normal generators for which the reduced resolvent is known in closed
form, so every quantity has an exact reference value.

---

## Requirements

```
python >= 3.10
numpy
scipy        # only for the root-find in genericity_codimension.py
```

Tested with numpy 2.4.4 and scipy 1.17.1. No other dependencies. Each script is
standalone and is run as `python3 code/<name>.py`; none takes arguments.

Two scripts are slow because they integrate the information operator on fine grids over
many observation windows: `temporal_resolution_test.py` and
`leading_vector_robustness.py` take on the order of tens of minutes.

---

## Test systems

| Used by | Generator | Notes |
|---|---|---|
| Alignment tests | `L_c = diag(0, −1, −2.5)`, `a = 1` | reduced resolvent exact |
| Krylov tests | `L_c = diag(0, −1, −2.3, −4.1)`, `a = 1` | 2-dim cyclic compression reference `{−2.3187, −1.0001}` |

The distinction between the full stable spectrum and the `q_c`-cyclic subspace is kept
throughout: only the cyclic part is algebraically visible.

---

## Scripts

**`verify_theorem_nu0.py`** — the two forward alignment laws. Integrates the information
operator, takes the principal-eigenvector angle, and compares against
`(3/2|a|T)‖S_c q_c‖` with stationary mixing retained and `6‖S_c²q_c‖/(|a|T²)` after the
DC-offset projection. Both ratios converge to unity, so leading coefficients are verified
and not only exponents.

**`verify_theorem_nu1.py`** — the exceptional class is non-empty. Constructs
`M = span{1, g}` with `g` a tuned combination of shifted Legendre modes, giving
`f(0) ≈ 2×10⁻¹⁴`, `f′(0) = −1.25`, `∫f² = 0.0520833`, then confirms the predicted `T⁻³`
law down to the double-precision eigenvector floor.

**`genericity_codimension.py`** — rank test behind the codimension theorem. Places `g` on
the unit sphere of the first three non-constant shifted Legendre modes and computes
finite-difference Jacobians of the jet maps. At the reported point `rank D J₁ = 1`
(singular value 0.761) and `rank D J₂ = 2` (singular values 4.530 and 0.0117). The small
second singular value is why transversality must be checked, not inferred from counting
equations.

**`krylov_reconstruction.py`** — the finite-order expansion of the normalized mixed block.
Compares the directly evaluated `r_T` against one-term and three-term predictions for a
polynomial and a non-polynomial nuisance shape.

**`extraction_optimisation_and_noise.py`** — coefficient extraction. Sweeps fit order,
node placement in `1/T`, column scaling and ridge penalty, then perturbs the processed
mixed block over 400 realizations per noise level. Shows that one additional fitted order
matters more than node optimization.

**`temporal_resolution_test.py`** — quadrature bias isolated from statistical error.
Noise-free pipeline at a sequence of sampling steps under three integration rules.
*The Simpson column is a negative control only*: that branch is index-shifted for even
sample counts and its numbers are not a physical result. Read the rectangle and trapezoid
columns, which show the plateau reached at `δt·Δ_fast ≲ 0.05` and failure at
`δt·Δ_fast ≳ 0.4`.

**`leading_vector_robustness.py`** — the end-to-end pipeline for the leading directed
vector `y₀ = S_c²q_c`: sampled sensitivities with additive noise, nuisance projection,
trapezoidal Fisher block, two-order fit. Reports median and interquartile spread of the
angular and norm errors over 60 realizations per noise level. This produces the table
quoted in the manuscript and closes the reproducibility gap noted in Supplement S10 of the
earlier archive.

**`common_pipeline_noise_comparison.py`** — the comparison the four-order claim rests on.
Injects noise once, at `sigma_s`, on the sampled sensitivity, and extracts both the leading
directed vector (two-power fit) and the two-dimensional Krylov spectral compression
(four-power fit) from the *same* noisy realization, 400 realizations per level. Usability
criteria and the admissibility filter are named constants at the top of the file and are
printed in the header of every run, so the reported separation is reproducible rather than
read off the table by eye. Nuisance space `span(1, exp(-3x))`, chosen because its first four
boundary derivatives are nonzero, which a four-power fit requires.

**`spectrum_recovery_illposedness.py`** — retained negative stress test. Documents the
earlier lower-order spectrum recovery in which the highest extracted coefficient and the
inferred eigenvalues carried large errors. It is deliberately **not** the final protocol;
it is kept as an auditable record of why the truncation-control rule was introduced.

---

## The three errors, and which script separates each

| Error | Controlled by | Script |
|---|---|---|
| Asymptotic truncation | number of fitted inverse-time powers, `N ≥ d + 2` | `extraction_optimisation_and_noise.py` |
| Temporal quadrature | sampling step against the fastest stable rate, `δt·Δ_fast` | `temporal_resolution_test.py` |
| Statistical | sensitivity noise `σ_s` | `leading_vector_robustness.py`, `extraction_optimisation_and_noise.py` |

The numerical thresholds are properties of the closure models, not universal constants.

---

## Reproducing the manuscript tables

| Manuscript location | Script |
|---|---|
| Sec. 7.1–7.2, App. A.1–A.2 | `verify_theorem_nu0.py`, `verify_theorem_nu1.py` |
| Sec. 7.3, App. A.3 | `genericity_codimension.py` |
| Sec. 8.5, App. A.4 | `krylov_reconstruction.py`, `extraction_optimisation_and_noise.py`, `spectrum_recovery_illposedness.py` |
| Sec. 8.4, App. A.5 | `temporal_resolution_test.py` |
| Sec. 8.4–8.5, App. A.6 | `leading_vector_robustness.py` |

Stochastic scripts use fixed seeds where a single realization is reported and unseeded
draws where a median over realizations is reported, so those medians will vary in the last
quoted digit between runs.

---

## Licence

MIT.
