import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(600); xq=(xq+1)/2; wq=wq/2
ip=lambda u,v: np.sum(wq*u(xq)*v(xq))
P1=lambda t: np.sqrt(3)*(2*np.asarray(t,float)-1)
P2=lambda t: np.sqrt(5)*(6*np.asarray(t,float)**2-6*np.asarray(t,float)+1)
u=lambda t: np.asarray(t,float)-0.5
th=np.arctan(-np.sqrt(5/3)); c1,c2=np.cos(th),np.sin(th)
g=lambda t: c1*P1(t)+c2*P2(t)

# ---------- full end-to-end test of the nu=1 prediction  sin ~ C_1 ||S_c^3 q_c|| / T^3
n=3; lam=np.array([0.0,-1.0,-2.5]); vc=np.array([1.,0,0])
Pc=np.outer(vc,vc); Qc=np.eye(n)-Pc
Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng=np.random.default_rng(7); Bc=rng.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc; A=1.0

def s_u(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return A*a*np.outer(t,vc) + A*(e-qc)@Sc.T

def sin_theta(T,M_basis,N=400000):
    t=np.linspace(0,T,N); dt=t[1]-t[0]
    S=s_u(t)
    B=np.stack([b(t/T) for b in M_basis],axis=1)          # N x m
    Q,_=np.linalg.qr(B); S=S-Q@(Q.T@S)*1.0                # remove nuisance (uniform grid)
    K=S.T@S*dt
    ev,V=np.linalg.eigh(K); w=V[:,np.argmax(ev)]
    return np.sqrt(max(0.,1-(w@vc)**2))

one=lambda t: np.ones_like(np.asarray(t,float))
f=lambda t: u(t)-ip(u,g)*g(t)
h=1e-6; fp0=(f(h)-f(0.0))/h; F=ip(f,f)
C1=abs(fp0)/(abs(a)*F)
S3=np.linalg.norm(np.linalg.matrix_power(Sc,3)@qc)
print(f"C_1 = |f'(0)|/(|a| int f^2) = {C1:.6f}    ||S_c^3 q_c|| = {S3:.6f}")
print()
print(f"{'T':>7} {'sin(theta)':>16} {'predicted C1*||S^3q||/T^3':>26} {'ratio':>8}")
for T in [80,160,320,640,1280]:
    s=sin_theta(T,[one,g]); p=C1*S3/T**3
    print(f"{T:>7} {s:16.6e} {p:26.6e} {s/p:8.4f}")
