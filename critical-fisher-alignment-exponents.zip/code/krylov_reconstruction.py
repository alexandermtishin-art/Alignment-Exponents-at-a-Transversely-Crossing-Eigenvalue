import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(800); xq=(xq+1)/2; wq=wq/2
ip=lambda a,b: np.sum(wq*a(xq)*b(xq))

n=4; lam=np.array([0.0,-1.0,-2.3,-4.1]); vc=np.zeros(n); vc[0]=1
Pc=np.outer(vc,vc); Qc=np.eye(n)-Pc
Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng=np.random.default_rng(3); Bc=rng.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc; A=1.0

def s_u(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return A*a*np.outer(t,vc)+A*(e-qc)@Sc.T

def z_transverse(T,basis,N=600000):
    t=np.linspace(0,T,N); dt=t[1]-t[0]; S=s_u(t)
    B=np.stack([b(t/T) for b in basis],axis=1)
    Q,_=np.linalg.qr(B); S=S-Q@(Q.T@S)
    K=S.T@S*dt; ev,V=np.linalg.eigh(K); w=V[:,np.argmax(ev)]
    w=w*np.sign(w@vc)
    return w-(w@vc)*vc                      # transverse part z_T

one=lambda t: np.ones_like(np.asarray(t,float))
def analyse(name,basis,orders=3):
    # build f = (I - Pi_M) x  on [0,1]
    G=np.array([[ip(g,h) for h in basis] for g in basis])
    b=np.array([ip(lambda s:s,g) for g in basis])
    c=np.linalg.solve(G,b)
    f=lambda s: np.asarray(s,float)-sum(ci*g(s) for ci,g in zip(c,basis))
    F=ip(f,f)
    h=1e-4
    d0=f(0.0); d1=(-3*f(0.0)+4*f(h)-f(2*h))/(2*h); d2=(f(0.0)-2*f(h)+f(2*h))/h**2
    der=[d0,d1,d2]
    print(f"\n--- {name}")
    print(f"    f(0)={d0:+.6f}  f'(0)={d1:+.6f}  f''(0)={d2:+.6f}   int f^2={F:.6f}")
    y=[np.linalg.matrix_power(Sc,j+2)@qc for j in range(orders)]
    pred=lambda T: sum((-1)**(j+1)*der[j]*y[j]/T**(j+2) for j in range(orders))/(a*F)
    print(f"    {'T':>6} {'||z_num - z_pred(1 term)||':>28} {'||z_num - z_pred(3 terms)||':>29}")
    for T in [60,120,240,480]:
        z=z_transverse(T,basis)
        p1=(-1)*der[0]*y[0]/T**2/(a*F)
        print(f"    {T:>6} {np.linalg.norm(z-p1):28.3e} {np.linalg.norm(z-pred(T)):29.3e}")

analyse("M = span{1}            (DC offset, f linear -> 2 Krylov vectors)", [one])
analyse("M = span{1, e^{-3x}}   (all derivatives nonzero -> full sequence)", [one, lambda s: np.exp(-3*np.asarray(s,float))])
