import numpy as np
np.set_printoptions(precision=6, suppress=True)

# ---- normal critical generator: L_c = diag(0, -1, -2.5) in an orthonormal basis
n=3
lam=np.array([0.0,-1.0,-2.5])
Lc=np.diag(lam)
vc=np.array([1.0,0,0]); Pc=np.outer(vc,vc); Qc=np.eye(n)-Pc
Ls=np.diag(lam[1:])                      # on Ran Q_c
Sc_full=np.zeros((n,n)); Sc_full[1:,1:]=np.linalg.inv(Ls)   # S_c = L_s^{-1} Q_c

# ---- perturbation B_c = L'(u_c):  a = v_c^† B_c v_c ,  q_c = Q_c B_c v_c
rng=np.random.default_rng(7)
Bc=rng.normal(size=(n,n))*0.5
Bc[0,0]=1.0                              # set a = 1 explicitly
a=vc@Bc@vc
qc=Qc@Bc@vc
A=1.0                                    # preparation amplitude

def s_u(t):
    """exact sensitivity, Sec.3:  P_c part = A a t v_c ; Q_c part = A S_c (e^{L_s t}-I) q_c"""
    out=A*a*t*vc.copy()
    e=np.zeros(n); e[1:]=np.exp(lam[1:]*t)*qc[1:]
    out=out+A*(Sc_full@(e-qc))
    return out

def sin_theta(T,N=200000,project=True):
    t=np.linspace(0,T,N); dt=t[1]-t[0]
    S=np.array([s_u(ti) for ti in t])            # N x n
    if project:                                  # remove span{1}: subtract time mean
        S=S-np.trapezoid(S,t,axis=0)/T
    K=np.einsum('ti,tj->ij',S,S)*dt
    ev,V=np.linalg.eigh(K)
    w=V[:,np.argmax(ev)]
    c=abs(w@vc)
    return np.sqrt(max(0.0,1-c*c))

Sc2qc=np.linalg.norm(Sc_full@Sc_full@qc)
Sc1qc=np.linalg.norm(Sc_full@qc)
print(f"a = {a:.6f}   ||S_c q_c|| = {Sc1qc:.6f}   ||S_c^2 q_c|| = {Sc2qc:.6f}")
print()
print("PROJECTED class (unknown DC offset, nu=0):  predicted  sin= 6||S_c^2 q_c||/(|a| T^2)")
print(f"{'T':>7} {'sin(theta) numeric':>20} {'predicted':>14} {'ratio':>9}")
for T in [40,80,160,320,640,1280]:
    s=sin_theta(T,project=True); p=6*Sc2qc/abs(a)/T**2
    print(f"{T:>7} {s:20.6e} {p:14.6e} {s/p:9.4f}")
print()
print("UNPROJECTED class (stationary mixing retained):  predicted  sin=(3/(2|a|T))||S_c q_c||")
print(f"{'T':>7} {'sin(theta) numeric':>20} {'predicted':>14} {'ratio':>9}")
for T in [40,80,160,320,640,1280]:
    s=sin_theta(T,project=False); p=1.5*Sc1qc/abs(a)/T
    print(f"{T:>7} {s:20.6e} {p:14.6e} {s/p:9.4f}")
