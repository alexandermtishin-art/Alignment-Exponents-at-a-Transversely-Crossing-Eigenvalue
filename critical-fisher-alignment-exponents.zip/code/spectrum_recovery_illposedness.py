import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(1000); xq=(xq+1)/2; wq=wq/2
ip=lambda a,b: np.sum(wq*a(xq)*b(xq))
n=4; lam=np.array([0.0,-1.0,-2.3,-4.1]); vc=np.zeros(n); vc[0]=1
Qc=np.eye(n)-np.outer(vc,vc); Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng=np.random.default_rng(3); Bc=rng.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc
def s_u(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return a*np.outer(t,vc)+(e-qc)@Sc.T
one=lambda t: np.ones_like(np.asarray(t,float)); gexp=lambda t: np.exp(-3*np.asarray(t,float))
basis=[one,gexp]
def rT(T,N=1200000):
    t=np.linspace(0,T,N); dt=t[1]-t[0]; S=s_u(t)
    B=np.stack([b(t/T) for b in basis],axis=1); Q,_=np.linalg.qr(B); S=S-Q@(Q.T@S)
    K=S.T@S*dt; return (Qc@K@vc)/(vc@K@vc)

# analytic f and its boundary derivatives (known: the nuisance shape is chosen by the experimenter)
G=np.array([[ip(g,h) for h in basis] for g in basis]); bb=np.array([ip(lambda s:s,g) for g in basis])
c=np.linalg.solve(G,bb); f=lambda s: np.asarray(s,float)-sum(ci*g(s) for ci,g in zip(c,basis))
F=ip(f,f); h=2e-3
der=[f(0.0),(-3*f(0.0)+4*f(h)-f(2*h))/(2*h),(2*f(0.0)-5*f(h)+4*f(2*h)-f(3*h))/h**2]

def spec(Y,k=2):
    V,_=np.linalg.qr(Y[:,:k])
    Ain=np.linalg.lstsq(V,Y[:,:k],rcond=None)[0]; Aout=np.linalg.lstsq(V,Y[:,1:k+1],rcond=None)[0]
    return np.sort(np.real(1/np.linalg.eigvals(Aout@np.linalg.inv(Ain))))

Ytrue=np.array([np.linalg.matrix_power(Sc,j+2)@qc for j in range(3)]).T[1:,:]
Ts=np.geomspace(30,3000,14); R=np.array([rT(T) for T in Ts])[:,1:]

print(f"true stable spectrum          : {lam[1:]}")
print(f"from EXACT Krylov vectors     : {np.round(spec(Ytrue),4)}   (2-dim cyclic block)")
print()
print("noise-free recovery from the measured mixed block r_T:")
for Nt in (3,):
    D=np.array([[T**-(j+2) for j in range(Nt)] for T in Ts])
    C,*_=np.linalg.lstsq(D,R,rcond=None)
    Y=np.array([C[j]*(a*F)/((-1)**(j+1)*der[j]) for j in range(Nt)]).T
    ang=[np.degrees(np.arccos(np.clip(abs(Y[:,j]@Ytrue[:,j])/(np.linalg.norm(Y[:,j])*np.linalg.norm(Ytrue[:,j])),-1,1))) for j in range(Nt)]
    rel=[abs(np.linalg.norm(Y[:,j])/np.linalg.norm(Ytrue[:,j])-1) for j in range(Nt)]
    print(f"  angle to true y_j (deg)     : {np.round(ang,4)}")
    print(f"  relative norm error         : {np.round(rel,5)}")
    print(f"  recovered spectrum          : {np.round(spec(Y),4)}")
print()
print("with multiplicative measurement noise on r_T (repeat, 200 trials):")
for eps in (1e-6,1e-4,1e-2):
    out=[]
    for _ in range(200):
        Rn=R*(1+eps*np.random.default_rng().normal(size=R.shape))
        C,*_=np.linalg.lstsq(D,Rn,rcond=None)
        Y=np.array([C[j]*(a*F)/((-1)**(j+1)*der[j]) for j in range(3)]).T
        try: out.append(spec(Y))
        except Exception: pass
    out=np.array(out)
    print(f"  eps={eps:.0e}:  median recovered = {np.round(np.median(out,axis=0),3)}   IQR = {np.round(np.percentile(out,75,axis=0)-np.percentile(out,25,axis=0),3)}")
