import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(1000); xq=(xq+1)/2; wq=wq/2
ip=lambda a,b: np.sum(wq*a(xq)*b(xq))
n=4; lam=np.array([0.0,-1.0,-2.3,-4.1]); vc=np.zeros(n); vc[0]=1
Qc=np.eye(n)-np.outer(vc,vc); Sc=np.zeros((n,n)); Sc[1:,1:]=np.diag(1/lam[1:])
rng=np.random.default_rng(3); Bc=rng.normal(size=(n,n))*0.5; Bc[0,0]=1.0
a=vc@Bc@vc; qc=Qc@Bc@vc
def s_u(t):
    e=np.zeros((len(t),n)); e[:,1:]=np.exp(np.outer(t,lam[1:]))*qc[1:]
    return a*np.outer(t,vc)+(e-qc)@Sc.T
one=lambda t: np.ones_like(np.asarray(t,float)); gexp=lambda t: np.exp(-3*np.asarray(t,float))
basis=[one,gexp]
def rT(T,N=1500000):
    t=np.linspace(0,T,N); dt=t[1]-t[0]; S=s_u(t)
    B=np.stack([b(t/T) for b in basis],axis=1); Q,_=np.linalg.qr(B); S=S-Q@(Q.T@S)
    K=S.T@S*dt; return (Qc@K@vc)/(vc@K@vc)
G=np.array([[ip(g,h) for h in basis] for g in basis]); bb=np.array([ip(lambda s:s,g) for g in basis])
c=np.linalg.solve(G,bb); f=lambda s: np.asarray(s,float)-sum(ci*g(s) for ci,g in zip(c,basis))
F=ip(f,f)
# high-order boundary derivatives of f, by Richardson-safe central differences
def deriv(k,h=0.02):
    from math import comb
    return sum((-1)**i*comb(k,i)*f(( k/2 - i)*h + 1e-12) for i in range(k+1))/h**k
der=[f(0.0)]
h=1e-3
der.append((-3*f(0.0)+4*f(h)-f(2*h))/(2*h))
der.append((2*f(0.0)-5*f(h)+4*f(2*h)-f(3*h))/h**2)
der.append((-5*f(0.0)+18*f(h)-24*f(2*h)+14*f(3*h)-3*f(4*h))/(2*h**3))
Ytrue=np.array([np.linalg.matrix_power(Sc,j+2)@qc for j in range(3)]).T[1:,:]

def extract(Ts,R,Nt,ridge=0.0,colscale=True):
    D=np.array([[T**-(j+2) for j in range(Nt)] for T in Ts])
    sc=np.linalg.norm(D,axis=0) if colscale else np.ones(Nt)
    Ds=D/sc
    if ridge>0:
        C=np.linalg.solve(Ds.T@Ds+ridge*np.eye(Nt), Ds.T@R)
    else:
        C,*_=np.linalg.lstsq(Ds,R,rcond=None)
    C=(C.T/sc).T
    return np.array([C[j]*(a*F)/((-1)**(j+1)*der[j]) for j in range(min(Nt,3))]).T, np.linalg.cond(Ds)

def spec(Y,k=2):
    V,_=np.linalg.qr(Y[:,:k])
    Ain=np.linalg.lstsq(V,Y[:,:k],rcond=None)[0]; Aout=np.linalg.lstsq(V,Y[:,1:k+1],rcond=None)[0]
    return np.sort(np.real(1/np.linalg.eigvals(Aout@np.linalg.inv(Ain))))

def report(tag,Ts,Nt,ridge=0.0):
    R=np.array([rT(T) for T in Ts])[:,1:]
    Y,cd=extract(Ts,R,Nt,ridge)
    ang=[np.degrees(np.arccos(np.clip(abs(Y[:,j]@Ytrue[:,j])/(np.linalg.norm(Y[:,j])*np.linalg.norm(Ytrue[:,j])),-1,1))) for j in range(Y.shape[1])]
    rel=[abs(np.linalg.norm(Y[:,j])/np.linalg.norm(Ytrue[:,j])-1) for j in range(Y.shape[1])]
    print(f"{tag:<46} cond={cd:9.2e}  ang={np.round(ang,3)}  relnorm={np.round(rel,4)}  spec={np.round(spec(Y),3)}")
    return Y

print(f"true stable spectrum {lam[1:]} ;  exact-Krylov 2-block gives {np.round(spec(Ytrue),4)}\n")
Tgeo=np.geomspace(30,3000,14)
# Chebyshev nodes in z = 1/T  (design basis is z^2*{1,z,...}: polynomial LS in z)
zmin,zmax=1/3000,1/30
k=np.arange(14); zche=(zmax+zmin)/2+(zmax-zmin)/2*np.cos((2*k+1)*np.pi/28)
Tche=np.sort(1/zche)

report("geometric T, N=3, no scaling",      Tgeo,3)
report("geometric T, N=4 (extra term)",     Tgeo,4)
report("Chebyshev in 1/T, N=3",             Tche,3)
report("Chebyshev in 1/T, N=4",             Tche,4)
report("Chebyshev in 1/T, N=5",             Tche,5)
for r in (1e-12,1e-8):
    report(f"Chebyshev, N=4, ridge={r:.0e}", Tche,4,ridge=r)

print()
print("=== noise sweep, improved extractor (Chebyshev nodes, N=4, ridge 1e-8) ===")
R0=np.array([rT(T) for T in Tche])[:,1:]
tgt=spec(Ytrue)
print(f"target (exact-Krylov 2-block): {np.round(tgt,4)}")
print(f"{'eps':>8} {'median lambda_1':>17} {'IQR':>8} {'median lambda_2':>17} {'IQR':>8} {'fail%':>7}")
for eps in (1e-8,1e-7,1e-6,1e-5,1e-4,1e-3):
    out=[];fail=0
    g=np.random.default_rng(11)
    for _ in range(400):
        Rn=R0*(1+eps*g.normal(size=R0.shape))
        try:
            Y,_=extract(Tche,Rn,4,ridge=1e-8)
            s=spec(Y)
            if np.all(np.isfinite(s)) and np.all(s<0) and np.all(s>-50): out.append(s)
            else: fail+=1
        except Exception: fail+=1
    out=np.array(out)
    if len(out)>10:
        m=np.median(out,axis=0); q=np.percentile(out,75,axis=0)-np.percentile(out,25,axis=0)
        print(f"{eps:8.0e} {m[0]:17.4f} {q[0]:8.4f} {m[1]:17.4f} {q[1]:8.4f} {100*fail/400:7.1f}")
    else:
        print(f"{eps:8.0e} {'--':>17} {'--':>8} {'--':>17} {'--':>8} {100*fail/400:7.1f}")
