import numpy as np
from numpy.polynomial.legendre import leggauss
xq,wq=leggauss(600); xq=(xq+1)/2; wq=wq/2
ip=lambda a,b: np.sum(wq*a(xq)*b(xq))
P1=lambda t: np.sqrt(3)*(2*np.asarray(t,float)-1)
P2=lambda t: np.sqrt(5)*(6*np.asarray(t,float)**2-6*np.asarray(t,float)+1)
P3=lambda t: np.sqrt(7)*(20*np.asarray(t,float)**3-30*np.asarray(t,float)**2+12*np.asarray(t,float)-1)
u=lambda t: np.asarray(t,float)-0.5

def jets(eta,k=3):
    """M = span{1, g(eta)}, g on the unit sphere in span{P1,P2,P3}; return (f(0),f'(0),f''(0))."""
    th,ph=eta
    c=np.array([np.cos(th)*np.cos(ph), np.cos(th)*np.sin(ph), np.sin(th)])
    g=lambda t: c[0]*P1(t)+c[1]*P2(t)+c[2]*P3(t)
    b=ip(u,g); f=lambda t: u(t)-b*g(t)
    h=1e-4
    f0=f(0.0); f1=(-3*f(0.0)+4*f(h)-f(2*h))/(2*h); f2=(f(0.0)-2*f(h)+f(2*h))/h**2
    return np.array([f0,f1,f2])[:k]

def jac(eta,k):
    J=np.zeros((k,2)); d=1e-5
    for i in range(2):
        e=np.zeros(2); e[i]=d
        J[:,i]=(jets(eta+e,k)-jets(eta-e,k))/(2*d)
    return J

print("=== 2. Codimension of {nu >= k} in a 2-parameter family of nuisance shapes ===")
print("    M = span{1, g}, g on the unit sphere of span{P1,P2,P3};  eta = (theta,phi) in R^2")
print()
from scipy.optimize import brentq
# locate a nu>=1 point on the slice phi fixed
eta1=None
for ph0 in np.linspace(-3.1,3.1,61):
    F=lambda th: jets(np.array([th,ph0]),1)[0]
    ths=np.linspace(-1.5,1.5,120); vals=np.array([F(t) for t in ths])
    sg=np.where(np.sign(vals[:-1])*np.sign(vals[1:])<0)[0]
    if len(sg):
        th0=brentq(F,ths[sg[0]],ths[sg[0]+1]); eta1=np.array([th0,ph0]); break
assert eta1 is not None, "no nu>=1 point found"
th0,ph0=eta1
j=jets(eta1,3)
print(f"  found nu>=1 point:  eta = ({th0:+.6f}, {ph0:+.6f})")
print(f"    f(0)={j[0]:+.3e}   f'(0)={j[1]:+.6f}   f''(0)={j[2]:+.6f}")
for k in (1,2):
    J=jac(eta1,k); r=np.linalg.matrix_rank(J,tol=1e-6)
    print(f"    rank D_eta F_{k} = {r}   (need {k} for codim {k})   singular values {np.linalg.svd(J,compute_uv=False)}")
print()
print("  -> F_1 submersion: {nu>=1} is a curve in a 2-parameter family = codimension 1")
print("  -> F_2 has rank 2: {nu>=2} is isolated points = codimension 2")
print()
print("=== 3. Corollary: nuisance shapes vanishing at t=0 ===")
for name,gg in [("g=P1-P1(0)  (g(0)=0)", lambda t: P1(t)-P1(0.0)),
                ("g=sin(pi x) (g(0)=0)", lambda t: np.sin(np.pi*np.asarray(t,float))),
                ("g=x^2       (g(0)=0)", lambda t: np.asarray(t,float)**2)]:
    # project out the constant first so M = span{1,g}
    g0=lambda t,gg=gg: gg(t)-ip(gg,lambda s:np.ones_like(s))
    nrm=np.sqrt(ip(g0,g0)); gn=lambda t,g0=g0,nrm=nrm: g0(t)/nrm
    b=ip(u,gn); f0=u(0.0)-b*gn(0.0)
    print(f"  {name:24}  f(0) = {f0:+.6f}   -> nu = 0")
print("  (any nuisance whose shape vanishes at the start of the record has g(0)-<g,1> != -1/2")
print("   generically, and cannot be tuned to nu>=1 without a constant-offset component)")
