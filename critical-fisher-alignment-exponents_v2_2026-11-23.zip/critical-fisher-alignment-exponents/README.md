# Optimal Sensor Directions for Locating a Stability Boundary: Convergence Rates and Cramér–Rao Cost under Nuisance-Parameter Elimination

Verification code for the manuscript by A. M. Tishin. Every numerical statement in the paper
and in its Supplementary Methods and Numerical Verification document is produced by one of
the scripts below; the console output of each is stored verbatim in `outputs/`.

These are **verification calculations**, not empirical data. All test systems are
finite-dimensional normal generators for which the reduced resolvent is known in closed
form, so every quantity has an exact reference value.

---

## Requirements

```
python >= 3.10
numpy
scipy
matplotlib   # only for rd_make_figure.py
```

Tested with numpy 2.5.3, scipy 1.18.1 and matplotlib 3.11.2. Each script is standalone,
takes no arguments and is run from the repository root as `python3 code/<name>.py`.
`temporal_resolution_test.py` and `leading_vector_robustness.py` take on the order of tens
of minutes; all other scripts finish within a few minutes.

---

## Quadrature

Unless a test is about sampling, the time integrals that define the Fisher operator are
evaluated by composite Gauss–Legendre quadrature (`code/quadrature.py`: 16 nodes on panels
of unit length), so the quadrature error is at round-off level. The misalignment angle is
computed as the norm of the stable components of the principal eigenvector, which avoids the
cancellation in `sqrt(1 − cos²θ)`. The reaction–diffusion scripts use the closed-form Fisher
operator. The sampling tests (`temporal_resolution_test.py`, `leading_vector_robustness.py`,
`common_pipeline_noise_comparison.py`) integrate sampled sensitivities on purpose, because
the effect of the sampling step is what they measure.

---

## Test systems

| Used by | Generator | Notes |
|---|---|---|
| Alignment tests | `L_c = diag(0, −1, −2.5)`, `a = 1` | reduced resolvent exact |
| Krylov tests | `L_c = diag(0, −1, −2.3, −4.1)`, `a = 1` | 2-dim cyclic compression reference `{−2.3187, −1.0001}` |
| Large-dimension example | `L(u) = D Δ_h + diag(r) + u diag(h)`, `n = 200, 800` | `D = 0.01`, `r = 1 + 0.6 cos 3πx − 0.8x`, `h = 0.5 + x`, Dirichlet |

---

## Scripts

**`verify_theorem_nu0.py`** — the two forward alignment laws, `(3/2|a|T)‖S_c q_c‖` with
stationary mixing retained and `6‖S_c²q_c‖/(|a|T²)` after the baseline projection. Both
ratios converge to unity; in the projected case `T(1 − ratio) = 2.0` at every `T`.

**`verify_theorem_nu1.py`** — the exceptional class is non-empty. `M = span{1, g}` with `g`
a tuned combination of shifted Legendre modes gives `f(0) ≈ 2×10⁻¹⁴`, `f′(0) = −1.25`,
`∫f² = 0.0520833`, `C₁ = 24`; the `T⁻³` law holds for `80 ≤ T ≤ 2560`.

**`genericity_codimension.py`** — rank test behind the codimension theorem: `rank D J₁ = 1`
(singular value 0.761) and `rank D J₂ = 2` (singular values 4.530 and 0.0117).

**`rd_model.py`** — reaction–diffusion model, critical point, closed-form Fisher operator
with and without an unknown baseline (library used by the `rd_*` scripts).

**`rd_make_figure.py`** — Fig. 1 (`figures/fig_rd.pdf`, `.png`) and `data/rd_results.csv`:
alignment angle, Cramér–Rao excess of the critical-mode sensor, point-sensor variance ratio.

**`rd_crosscheck_fd.py`** — independent check (`n = 60`, `T = 100`): numerical derivative of
the matrix exponential and quadrature, compared through `sin θ_T`.

**`rd_fisher_frechet_check.py`** — Fisher operator from the Fréchet derivative of the matrix
exponential against the closed form; Krylov coefficient of the `T⁻³` correction.

**`rd_verify_numbers.py`** — recomputes every number quoted in Section 7.4 and Proposition 3.

**`rd_plugin_rotation.py`** — rotation of `v_c` under a pilot error `δu` in `u_c` (Rule 1):
`sin/δu → ‖S_c q_c‖`.

**`krylov_reconstruction.py`** — finite-order expansion of the normalized mixed block,
one-term and three-term predictions for a polynomial and a non-polynomial nuisance shape.

**`extraction_optimisation_and_noise.py`** — coefficient extraction: fit order, node
placement in `1/T`, ridge penalty, and a 400-realization perturbation sweep for four and
five fitted powers.

**`temporal_resolution_test.py`** — quadrature bias of sampled sensitivities under three
integration rules. *The Simpson column is a negative control only*: that branch is
index-shifted for even sample counts. Read the rectangle and trapezoid columns.

**`leading_vector_robustness.py`** — end-to-end pipeline for the leading directed vector
`y₀ = S_c²q_c`: sampled sensitivities with additive noise, nuisance projection, trapezoidal
Fisher block, two-order fit; 60 realizations per noise level (Table S1).

**`common_pipeline_noise_comparison.py`** — injects noise once, at `sigma_s`, and extracts
both the leading vector (two-power fit) and the two-dimensional Krylov compression
(four-power fit) from the same realization, 400 realizations per level. Usability criteria
are named constants printed in the header of every run.

**`spectrum_recovery_illposedness.py`** — retained negative control: a three-power fit
without the additional order, showing the truncation failure that the order rule prevents.

---

## Reproducing the manuscript

| Manuscript location | Supplement | Script |
|---|---|---|
| Sec. 7.1–7.2, Table 1 | S3, S4 | `verify_theorem_nu0.py`, `verify_theorem_nu1.py` |
| Sec. 7.3 | S5 | `genericity_codimension.py` |
| Sec. 4.4, Sec. 7.4, Fig. 1, Rule 1 | S6 | `rd_*.py` |
| Sec. 8.2 | S7 | `krylov_reconstruction.py` |
| Sec. 8.4–8.5 | S8, S9, S13 | `extraction_optimisation_and_noise.py`, `spectrum_recovery_illposedness.py` |
| Sec. 8.4 | S9, S14 | `temporal_resolution_test.py` |
| Sec. 8.4–8.5, Rule 6 | S10 | `leading_vector_robustness.py`, `common_pipeline_noise_comparison.py` |

Stochastic scripts use fixed seeds where a single realization is reported and unseeded
draws where a median over realizations is reported, so those medians can vary in the last
quoted digit between runs.

---

## Licence

MIT.
