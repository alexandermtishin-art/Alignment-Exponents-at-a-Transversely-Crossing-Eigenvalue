"""Large-dimension test: discretized reaction-diffusion generator near loss of stability.
L(u) = D*Lap_Dirichlet + diag(r(x)) + u*diag(h(x)) on n interior nodes of [0,1].
Analytic Fisher operator in the eigenbasis of the normal (symmetric) critical generator.
"""
import numpy as np
from scipy.optimize import brentq

def build(n, D=0.01):
    x = np.arange(1, n+1)/(n+1); hx = 1/(n+1)
    lap = (np.diag(-2*np.ones(n)) + np.diag(np.ones(n-1), 1) + np.diag(np.ones(n-1), -1))/hx**2
    r = 1.0 + 0.6*np.cos(3*np.pi*x) - 0.8*x          # heterogeneous reaction rate
    h = 0.5 + x                                       # spatially varying parameter coupling
    L0 = D*lap + np.diag(r)
    top = lambda u: np.linalg.eigvalsh(L0 + u*np.diag(h))[-1]
    uc = brentq(top, -50, 50)
    Lc = L0 + uc*np.diag(h)
    mu, U = np.linalg.eigh(Lc)                        # ascending; last is critical (=0)
    vc = U[:, -1] * np.sign(U[:, -1].sum())
    U[:, -1] = vc
    B = np.diag(h)
    a = vc @ B @ vc
    q_phys = B @ vc - a*vc                            # q_c = Q_c B_c v_c
    q = U[:, :-1].T @ q_phys                          # stable modal components
    return dict(x=x, n=n, uc=uc, mu_s=mu[:-1], mu_c=mu[-1], U=U, vc=vc, a=a, q=q)

def E(m, T):   # int_0^T e^{m t} dt, m<0
    return np.expm1(m*T)/m
def I1(m, T):  # int_0^T t e^{m t} dt
    return np.exp(m*T)*(T/m - 1/m**2) + 1/m**2

def fisher(M, T, projected=True, A=1.0):
    mu, q, a = M['mu_s'], M['q'], M['a']
    k = len(mu)
    # Gram of functions p(t)=t, e_k(t)=(e^{mu_k t}-1)/mu_k on [0,T]
    mm = mu[:, None] + mu[None, :]
    Ejk = E(mm, T); Ej = E(mu, T)
    G_ss = (Ejk - Ej[:, None] - Ej[None, :] + T)/(mu[:, None]*mu[None, :])
    if projected:
        Ebar = (Ej/T - 1)/mu                          # means of e_k
        G_ss = G_ss - T*np.outer(Ebar, Ebar)
        G_ps = (I1(mu, T) - 0.5*T*Ej)/mu              # centred <p,e_k>, cancellation-free form
        G_pp = T**3/12
    else:
        G_ps = (I1(mu, T) - 0.5*T**2)/mu
        G_pp = T**3/3
    K = np.empty((k+1, k+1))
    K[0, 0] = (A*a)**2*G_pp
    K[0, 1:] = K[1:, 0] = (A*a)*(A*q)*G_ps
    K[1:, 1:] = (A**2)*np.outer(q, q)*G_ss
    return K   # coordinates: (critical, stable modes)

def analyse(M, T, projected=True):
    K = fisher(M, T, projected)
    w, V = np.linalg.eigh(K)
    lam1 = w[-1]; v = V[:, -1]
    sin_th = np.sqrt(max(0.0, 1 - v[0]**2))
    mu, q, a = M['mu_s'], M['q'], M['a']
    if projected:
        pred = 6*np.linalg.norm(q/mu**2)/(abs(a)*T**2)
    else:
        pred = 1.5*np.linalg.norm(q/mu)/(abs(a)*T)
    # Cramer-Rao variance ratios (sensor Fisher info c^T K c in physical space)
    Kphys = M['U'] @ np.roll(np.roll(K, -1, 0), -1, 1) @ M['U'].T  # reorder to (stable..., critical)
    info_vc = M['vc'] @ Kphys @ M['vc']
    ipt = np.argmax(np.abs(M['vc']))
    info_pt = Kphys[ipt, ipt]
    # Krylov leading vector from mixed block (projected class): y0 ~ 2 b_T/(a T)
    b = K[1:, 0]
    y0_est = 2*b/(a*T) if projected else None
    y0_true = q/mu**2
    return dict(T=T, sin=sin_th, pred=pred, ratio=sin_th/pred,
                var_ratio_vc=lam1/info_vc, var_ratio_pt=lam1/info_pt,
                y0_err=(np.linalg.norm(y0_est - y0_true)/np.linalg.norm(y0_true)) if projected else None,
                lam2_over_lam1=w[-2]/lam1)
