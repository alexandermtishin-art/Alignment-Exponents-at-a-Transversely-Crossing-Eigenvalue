import os
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.dirname(HERE)
import numpy as np, rd_model as R, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib import font_manager
fam = 'Liberation Serif' if any('Liberation Serif' in f.name for f in font_manager.fontManager.ttflist) else 'DejaVu Serif'
plt.rcParams.update({'font.family': fam, 'font.size': 9, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6,
                     'ytick.major.width': 0.6, 'axes.edgecolor': '#52514e', 'axes.labelcolor': '#0b0b0b', 'mathtext.fontset': 'stix'})
C1, C2, C3 = '#2a78d6', '#eb6834', '#1baf7a'
Ts = np.array([50, 70, 100, 140, 200, 280, 400, 560, 800, 1130, 1600])
rows = []
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.5), constrained_layout=True)
# (a) profiles, n=200
M = R.build(200)
x = M['x']; Us = M['U'][:, :-1]
y0 = Us @ (M['q']/M['mu_s']**2)
rT = R.fisher(M, 400, True)[1:, 0]; y0e = Us @ (2*rT/(M['a']*400))
s = 1/np.max(np.abs(y0))
ax[0].plot(x, M['vc']/np.max(np.abs(M['vc'])), color=C1, lw=2, label=r'critical mode $v_c$')
ax[0].plot(x, y0*s, color=C2, lw=2, label=r'$S_c^2q_c$ (exact)')
ax[0].plot(x[::8], (y0e*s)[::8], 'o', ms=4.5, mfc='white', mec=C3, mew=1.4, label=r'from $b_T$, $T=400$')
ax[0].axhline(0, color='#c3c2b7', lw=0.6, zorder=0)
ax[0].set_xlabel('position $x$'); ax[0].set_ylabel('normalized profile')
ax[0].set_ylim(-1.15, 1.75); ax[0].legend(frameon=False, fontsize=7.5, loc='upper left', ncol=1); ax[0].set_title('(a)', loc='left', fontsize=9)
# (b) angle, (c) Cramér–Rao excess
for n, mk in ((200, 'o'), (800, 's')):
    Mn = R.build(n)
    for proj, col in ((False, C1), (True, C2)):
        res = [R.analyse(Mn, T, proj) for T in Ts]
        sn = np.array([r['sin'] for r in res]); pr = np.array([r['pred'] for r in res])
        ex = np.array([r['var_ratio_vc'] - 1 for r in res])
        lab = ('mixing retained' if not proj else 'baseline projected') + f', $n={n}$'
        ax[1].loglog(Ts, sn, mk, ms=7 if n == 200 else 3.0, mfc='white' if n == 800 else col, mec=col, mew=0.8, ls='none', zorder=3 if n==800 else 2)
        ax[2].loglog(Ts, ex, mk, ms=7 if n == 200 else 3.0, mfc='white' if n == 800 else col, mec=col, mew=0.8, ls='none', zorder=3 if n==800 else 2)
        if n == 200:
            ax[1].loglog(Ts, pr, color=col, lw=1.2, ls='--')
            ax[2].loglog(Ts, pr**2, color=col, lw=1.2, ls='--')
        for T, r in zip(Ts, res):
            rows.append((n, 'projected' if proj else 'retained', T, r['sin'], r['ratio'], r['var_ratio_vc']-1, r['var_ratio_pt'], r['y0_err']))
ax[1].set_xlabel('observation time $T$'); ax[1].set_ylabel(r'$\sin\theta_T$'); ax[1].set_title('(b)', loc='left', fontsize=9)
ax[1].text(700, 3.2e-3, r'$\propto T^{-1}$', color='#0b0b0b', fontsize=8); ax[1].text(110, 2.5e-4, r'$\propto T^{-2}$', color='#0b0b0b', fontsize=8)
from matplotlib.lines import Line2D
hs=[Line2D([],[],color=C1,lw=2,label='mixing retained'),Line2D([],[],color=C2,lw=2,label='baseline projected'),
    Line2D([],[],color='#52514e',lw=1.2,ls='--',label='leading-order prediction'),
    Line2D([],[],marker='o',ms=7,color='#52514e',ls='none',label='$n=200$'),
    Line2D([],[],marker='s',ms=3,mfc='white',mec='#52514e',ls='none',label='$n=800$')]
ax[2].legend(handles=hs,frameon=False,fontsize=6.8,loc='lower left')
ax[2].set_xlabel('observation time $T$'); ax[2].set_ylabel(r'$\mathrm{Var}(v_c)/\mathrm{Var}(w_T)-1$'); ax[2].set_title('(c)', loc='left', fontsize=9)
for a_ in ax[1:]:
    a_.grid(True, which='major', color='#e4e3dd', lw=0.5); a_.set_axisbelow(True)
fig.savefig(os.path.join(ROOT,'figures','fig_rd.png'), dpi=300); fig.savefig(os.path.join(ROOT,'figures','fig_rd.pdf'))
np.savetxt(os.path.join(ROOT,'data','rd_results.csv'), np.array([(r[0], 0 if r[1]=='retained' else 1, r[2], r[3], r[4], r[5], r[6], -1 if r[7] is None else r[7]) for r in rows]),
           delimiter=',', header='n,projected,T,sin_theta,ratio_to_prediction,var_excess_vc,var_ratio_point,y0_rel_err', fmt='%.10g')
print(fam)
